package com.example.conductordesign;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class UserDashboardActivity extends AppCompatActivity {

    private EditText startLocationInput, endLocationInput, distanceInput;
    private Button createRequestButton, logoutButton;
    private ListView requestListView;
    private DatabaseHelper databaseHelper;
    private RequestAdapter requestAdapter;
    private ArrayList<Request> requestList;

    private int userId = 1; // Harcodeado para pruebas (en producción obtendrás esto al iniciar sesión)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);

        databaseHelper = new DatabaseHelper(this);

        startLocationInput = findViewById(R.id.startLocationInput);
        endLocationInput = findViewById(R.id.endLocationInput);
        distanceInput = findViewById(R.id.distanceInput);
        createRequestButton = findViewById(R.id.createRequestButton);
        logoutButton = findViewById(R.id.logoutButton);
        requestListView = findViewById(R.id.requestListView);

        loadRequests();

        createRequestButton.setOnClickListener(view -> {
            createRequestFromInput();
        });

        logoutButton.setOnClickListener(view -> {
            logout();
        });
    }

    private void loadRequests() {
        requestList = databaseHelper.getAllRequests(userId);
        requestAdapter = new RequestAdapter(this, requestList, databaseHelper);
        requestListView.setAdapter(requestAdapter);
    }

    private void createRequestFromInput() {
        String ubicacionInicio = startLocationInput.getText().toString();
        String destinoFinal = endLocationInput.getText().toString();
        String distanciaText = distanceInput.getText().toString();

        if (ubicacionInicio.isEmpty() || destinoFinal.isEmpty() || distanciaText.isEmpty()) {
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        double distancia;
        try {
            distancia = Double.parseDouble(distanciaText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Distancia inválida", Toast.LENGTH_SHORT).show();
            return;
        }

        double precio = distancia * 500;

        boolean success = databaseHelper.createRequest(userId, ubicacionInicio, destinoFinal, precio);
        if (success) {
            Toast.makeText(this, "Solicitud creada exitosamente", Toast.LENGTH_SHORT).show();
            clearInputFields();
            loadRequests(); // Recargar la lista
        } else {
            Toast.makeText(this, "Error al crear la solicitud", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearInputFields() {
        startLocationInput.setText("");
        endLocationInput.setText("");
        distanceInput.setText("");
    }

    private void logout() {
        Intent intent = new Intent(UserDashboardActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
