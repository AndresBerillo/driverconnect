package com.example.conductordesign;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import java.util.ArrayList;

public class RequestAdapter extends ArrayAdapter<Request> {

    private Context context;
    private ArrayList<Request> requests;
    private DatabaseHelper databaseHelper;

    public RequestAdapter(Context context, ArrayList<Request> requests, DatabaseHelper databaseHelper) {
        super(context, 0, requests);
        this.context = context;
        this.requests = requests;
        this.databaseHelper = databaseHelper;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.request_item, parent, false);
        }

        Request request = requests.get(position);

        TextView requestInfoTextView = convertView.findViewById(R.id.requestInfoTextView);
        Button deleteRequestButton = convertView.findViewById(R.id.deleteRequestButton);

        requestInfoTextView.setText(
                "Inicio: " + request.getUbicacionInicio() +
                        "\nDestino: " + request.getDestinoFinal() +
                        "\nPrecio: $" + request.getPrecio()
        );

        deleteRequestButton.setOnClickListener(view -> {
            boolean success = databaseHelper.deleteRequest(request.getId());
            if (success) {
                requests.remove(request);
                notifyDataSetChanged();
                Toast.makeText(context, "Solicitud eliminada", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Error al eliminar la solicitud", Toast.LENGTH_SHORT).show();
            }
        });

        return convertView;
    }
}
