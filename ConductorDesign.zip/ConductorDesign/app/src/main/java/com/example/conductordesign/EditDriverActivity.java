package com.example.conductordesign;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EditDriverActivity extends AppCompatActivity {

    private EditText driverNameInput, driverPhoneInput;
    private Button saveChangesButton;
    private DatabaseHelper databaseHelper;
    private int driverId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_driver);

        driverNameInput = findViewById(R.id.driverNameInput);
        driverPhoneInput = findViewById(R.id.driverPhoneInput);
        saveChangesButton = findViewById(R.id.saveChangesButton);
        databaseHelper = new DatabaseHelper(this);

        Intent intent = getIntent();
        driverId = intent.getIntExtra("driverId", -1);
        String driverName = intent.getStringExtra("driverName");
        String driverPhone = intent.getStringExtra("driverPhone");

        driverNameInput.setText(driverName);
        driverPhoneInput.setText(driverPhone);

        saveChangesButton.setOnClickListener(view -> {
            String newName = driverNameInput.getText().toString();
            String newPhone = driverPhoneInput.getText().toString();

            if (newName.isEmpty() || newPhone.isEmpty()) {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            } else {
                boolean success = databaseHelper.updateDriver(driverId, newName, newPhone, "Disponible");
                if (success) {
                    Toast.makeText(this, "Chofer actualizado exitosamente", Toast.LENGTH_SHORT).show();
                    Intent backIntent = new Intent(EditDriverActivity.this, AdminDriverActivity.class);
                    startActivity(backIntent);
                    finish();
                } else {
                    Toast.makeText(this, "Error al actualizar chofer", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
