package com.example.conductordesign;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import java.util.ArrayList;

public class DriverAdapter extends ArrayAdapter<Driver> {

    private Context context;
    private ArrayList<Driver> drivers;
    private DatabaseHelper databaseHelper;

    public DriverAdapter(Context context, ArrayList<Driver> drivers, DatabaseHelper databaseHelper) {
        super(context, 0, drivers);
        this.context = context;
        this.drivers = drivers;
        this.databaseHelper = databaseHelper;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.driver_item, parent, false);
        }

        Driver driver = drivers.get(position);

        TextView nameTextView = convertView.findViewById(R.id.driverNameTextView);
        TextView phoneTextView = convertView.findViewById(R.id.driverPhoneTextView);
        Button deleteButton = convertView.findViewById(R.id.deleteDriverButton);
        Button editButton = convertView.findViewById(R.id.editDriverButton);

        nameTextView.setText(driver.getName());
        phoneTextView.setText(driver.getPhone());

        deleteButton.setOnClickListener(view -> {
            boolean success = databaseHelper.deleteDriver(driver.getId());
            if (success) {
                drivers.remove(driver);
                notifyDataSetChanged();
                Toast.makeText(context, "Chofer eliminado", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Error al eliminar chofer", Toast.LENGTH_SHORT).show();
            }
        });

        editButton.setOnClickListener(view -> {
            Intent intent = new Intent(context, EditDriverActivity.class);
            intent.putExtra("driverId", driver.getId());
            intent.putExtra("driverName", driver.getName());
            intent.putExtra("driverPhone", driver.getPhone());
            context.startActivity(intent);
        });

        return convertView;
    }
}

