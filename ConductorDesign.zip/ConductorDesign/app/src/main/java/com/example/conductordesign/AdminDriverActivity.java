package com.example.conductordesign;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class AdminDriverActivity extends AppCompatActivity {

    private Button backToDashboardButton, addDriverButton;
    private ListView driverListView;
    private DatabaseHelper databaseHelper;
    private DriverAdapter driverAdapter;
    private ArrayList<Driver> driverList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_driver);

        backToDashboardButton = findViewById(R.id.backToDashboardButton);
        addDriverButton = findViewById(R.id.addDriverButton);
        driverListView = findViewById(R.id.driverListView);
        databaseHelper = new DatabaseHelper(this);

        loadDrivers();

        backToDashboardButton.setOnClickListener(view -> {
            Intent intent = new Intent(AdminDriverActivity.this, AdminDashboardActivity.class);
            startActivity(intent);
            finish();
        });

        addDriverButton.setOnClickListener(view -> {
            Intent intent = new Intent(AdminDriverActivity.this, CreateDriverActivity.class);
            startActivity(intent);
        });
    }

    private void loadDrivers() {
        driverList = databaseHelper.getAllDrivers();
        if (driverAdapter == null) {
            driverAdapter = new DriverAdapter(this, driverList, databaseHelper);
            driverListView.setAdapter(driverAdapter);
        } else {
            driverAdapter.clear();
            driverAdapter.addAll(driverList);
            driverAdapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDrivers(); // Recarga la lista al volver a la actividad
    }
}

