package com.example.conductordesign;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CreateDriverActivity extends AppCompatActivity {

    private EditText driverNameInput, driverPhoneInput, driverStatusInput;
    private Button saveDriverButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_driver);

        driverNameInput = findViewById(R.id.driverNameInput);
        driverPhoneInput = findViewById(R.id.driverPhoneInput);
        driverStatusInput = findViewById(R.id.driverStatusInput);
        saveDriverButton = findViewById(R.id.saveDriverButton);
        databaseHelper = new DatabaseHelper(this);

        saveDriverButton.setOnClickListener(view -> {
            String name = driverNameInput.getText().toString();
            String phone = driverPhoneInput.getText().toString();
            String status = driverStatusInput.getText().toString();

            if (name.isEmpty() || phone.isEmpty() || status.isEmpty()) {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            } else {
                boolean success = databaseHelper.createDriver(name, phone, status);
                if (success) {
                    Toast.makeText(this, "Chofer registrado exitosamente", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(CreateDriverActivity.this, AdminDriverActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(this, "Error al registrar chofer", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
