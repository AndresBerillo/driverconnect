package com.example.conductordesign;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "ConductorApp.db";
    private static final int DATABASE_VERSION = 6;

    // Tabla Usuarios
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_USERTYPE = "usertype";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "email TEXT UNIQUE," +
                "password TEXT," +
                "usertype TEXT)";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_DRIVERS_TABLE = "CREATE TABLE drivers (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "phone TEXT," +
                "status TEXT)";
        db.execSQL(CREATE_DRIVERS_TABLE);

        String CREATE_REQUESTS_TABLE = "CREATE TABLE requests (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "userId INTEGER," +
                "ubicacionInicio TEXT," +
                "destinoFinal TEXT," +
                "precio REAL," +
                "FOREIGN KEY(userId) REFERENCES users(id))";
        db.execSQL(CREATE_REQUESTS_TABLE);

        // Agregar superusuario predeterminado
        String INSERT_ADMIN_USER = "INSERT INTO users (name, email, password, usertype) " +
                "VALUES ('Admin', 'admin@admin.com', 'admin123', 'Administrador')";
        db.execSQL(INSERT_ADMIN_USER);
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS drivers");
        db.execSQL("DROP TABLE IF EXISTS requests");
        onCreate(db);
    }

    public boolean registerUser(String name, String email, String password, String userType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_USERTYPE, userType);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1; // Return true if inserted successfully
    }

    public boolean validateLogin(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null,
                COLUMN_EMAIL + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{email, password}, null, null, null);
        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }
    public ArrayList<User> getAllUsers() {
        ArrayList<User> userList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("users", null, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String email = cursor.getString(cursor.getColumnIndexOrThrow("email"));
                userList.add(new User(id, name, email));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return userList;
    }

    public String getUserType(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("users", new String[]{"usertype"},
                "email=? AND password=?", new String[]{email, password},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            String userType = cursor.getString(cursor.getColumnIndexOrThrow("usertype"));
            cursor.close();
            return userType;
        }
        return null; // Retorna null si no encuentra al usuario
    }


    public boolean deleteUser(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("users", "id=?", new String[]{String.valueOf(userId)});
        return result > 0;
    }

    public boolean updateUser(int userId, String newName, String newEmail) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", newName);
        values.put("email", newEmail);

        // Actualizar el usuario con el ID especificado
        int rowsAffected = db.update("users", values, "id=?", new String[]{String.valueOf(userId)});
        return rowsAffected > 0; // Retorna true si se actualizó al menos una fila
    }


    // Obtener todos los choferes
    public ArrayList<Driver> getAllDrivers() {
        ArrayList<Driver> driverList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("drivers", null, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String phone = cursor.getString(cursor.getColumnIndexOrThrow("phone"));
                String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));
                driverList.add(new Driver(id, name, phone, status));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return driverList;
    }

    // Crear chofer
    public boolean createDriver(String name, String phone, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("phone", phone);
        values.put("status", status);
        long result = db.insert("drivers", null, values);
        return result != -1;
    }

    // Eliminar chofer
    public boolean deleteDriver(int driverId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("drivers", "id=?", new String[]{String.valueOf(driverId)});
        return result > 0;
    }

    // Editar chofer
    public boolean updateDriver(int driverId, String name, String phone, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("phone", phone);
        values.put("status", status);
        int result = db.update("drivers", values, "id=?", new String[]{String.valueOf(driverId)});
        return result > 0;
    }

    // Crear una solicitud
    public boolean createRequest(int userId, String ubicacionInicio, String destinoFinal, double precio) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("userId", userId);
        values.put("ubicacionInicio", ubicacionInicio);
        values.put("destinoFinal", destinoFinal);
        values.put("precio", precio);
        long result = db.insert("requests", null, values);
        return result != -1;
    }

    // Obtener todas las solicitudes de un usuario
    public ArrayList<Request> getAllRequests(int userId) {
        ArrayList<Request> requestList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("requests", null, "userId=?",
                new String[]{String.valueOf(userId)}, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String ubicacionInicio = cursor.getString(cursor.getColumnIndexOrThrow("ubicacionInicio"));
                String destinoFinal = cursor.getString(cursor.getColumnIndexOrThrow("destinoFinal"));
                double precio = cursor.getDouble(cursor.getColumnIndexOrThrow("precio"));
                requestList.add(new Request(id, ubicacionInicio, destinoFinal, precio));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return requestList;
    }

    // Eliminar una solicitud
    public boolean deleteRequest(int requestId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("requests", "id=?", new String[]{String.valueOf(requestId)});
        return result > 0;
    }


}

