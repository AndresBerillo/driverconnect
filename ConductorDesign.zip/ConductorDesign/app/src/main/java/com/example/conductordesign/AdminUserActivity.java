package com.example.conductordesign;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class AdminUserActivity extends AppCompatActivity {

    private Button backToDashboardButton, addUserButton;
    private ListView userListView;
    private DatabaseHelper databaseHelper;
    private UserAdapter userAdapter;
    private ArrayList<User> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_user);

        backToDashboardButton = findViewById(R.id.backToDashboardButton);
        addUserButton = findViewById(R.id.addUserButton);
        userListView = findViewById(R.id.userListView);
        databaseHelper = new DatabaseHelper(this);

        loadUsers();

        backToDashboardButton.setOnClickListener(view -> {
            Intent intent = new Intent(AdminUserActivity.this, AdminDashboardActivity.class);
            startActivity(intent);
            finish();
        });

        addUserButton.setOnClickListener(view -> {
            Intent intent = new Intent(AdminUserActivity.this, RegisterActivity.class);
            intent.putExtra("source", "admin");
            startActivity(intent);
        });

    }

    private void loadUsers() {
        userList = databaseHelper.getAllUsers();
        if (userAdapter == null) {
            userAdapter = new UserAdapter(this, userList, databaseHelper);
            userListView.setAdapter(userAdapter);
        } else {
            userAdapter.clear();
            userAdapter.addAll(userList);
            userAdapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUsers(); // Recarga la lista al volver a la actividad
    }
}




