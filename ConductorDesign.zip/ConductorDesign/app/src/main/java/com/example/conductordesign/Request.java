package com.example.conductordesign;

public class Request {
    private int id;
    private String ubicacionInicio;
    private String destinoFinal;
    private double precio;

    public Request(int id, String ubicacionInicio, String destinoFinal, double precio) {
        this.id = id;
        this.ubicacionInicio = ubicacionInicio;
        this.destinoFinal = destinoFinal;
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public String getUbicacionInicio() {
        return ubicacionInicio;
    }

    public String getDestinoFinal() {
        return destinoFinal;
    }

    public double getPrecio() {
        return precio;
    }
}
